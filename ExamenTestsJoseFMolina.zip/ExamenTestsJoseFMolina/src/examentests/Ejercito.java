package examentests;

public class Ejercito {

    public Ejercito() {

    }

    public boolean verificarEdad(int edad) throws MiExcepcion {

        if (edad <= -1) {
            throw new MiExcepcion("No se acepta edad negativa");
        } else if (edad >= 0 && edad <= 17) {
            return false;
        } else if (edad >= 41) {
            return false;
        }
        return true;
    }

    public int nivelAcceso(boolean ap1, boolean ap2, boolean ap3) {
        
        if (ap1 == true && ap2 == true) {
            return 1;
        } else if (ap3 == true) {
            return 2;
        }
        return 3;
    }
}
