
package examentests;

public class MiExcepcion extends Exception{
    
    public MiExcepcion(String message){
        super(message);
    }
    
}
