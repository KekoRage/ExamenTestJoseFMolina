
import examentests.Ejercito;
import examentests.MiExcepcion;
import java.util.ArrayList;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

@RunWith (value = Parameterized.class)
public class EjercitoTests {

    private Ejercito e;
    private int edad;
    private boolean esperado;
    
    public EjercitoTests(int edad, boolean esperado){
        this.edad = edad;
        this.esperado = esperado;    
    }
    
    @Before
    public void before() {
        e = new Ejercito();
    }


    @Parameterized.Parameters
    public static ArrayList<Object[]> getDatos() {
        ArrayList<Object[]> prueba = new ArrayList<>();
        prueba.add(new Object[]{-5, false});
        prueba.add(new Object[]{6, false});
        prueba.add(new Object[]{24, true});
        prueba.add(new Object[]{60, false});

        return prueba;
    }

    @Test
    public void testEdad() throws MiExcepcion {
        assertEquals(esperado, e.verificarEdad(edad));
    }

}
