
import examentests.Ejercito;
import java.util.ArrayList;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

@RunWith(value = Parameterized.class)
public class AccesoTests {

    private Ejercito e;
    private boolean ap1, ap2, ap3;
    private int rdo;

    @Before
    public void before() {
        e = new Ejercito();
    }

    public AccesoTests(boolean ap1, boolean ap2, boolean ap3, int rdo) {
        this.ap1 = ap1;
        this.ap2 = ap2;
        this.ap3 = ap3;
        this.rdo = rdo;
    }

    @Parameterized.Parameters
    public static ArrayList<Object[]> getDatos() {
        ArrayList<Object[]> prueba = new ArrayList<>();
        prueba.add(new Object[]{true, true, true, 1});
        prueba.add(new Object[]{true, true, false, 1});
        prueba.add(new Object[]{false, false, true, 2});
        prueba.add(new Object[]{true, false, true, 2});
        prueba.add(new Object[]{false, true, true, 2});
        prueba.add(new Object[]{true, false, false, 3});
        prueba.add(new Object[]{false, true, false, 3});
        prueba.add(new Object[]{false, false, false, 3});

        return prueba;
    }
    

    @Test
    public void testAcceso() {
        assertEquals(rdo, e.nivelAcceso(ap1, ap2, ap3));
    }

}
