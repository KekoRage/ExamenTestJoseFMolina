
import org.junit.runner.RunWith;
import org.junit.runners.Suite;


@RunWith(Suite.class)
@Suite.SuiteClasses({AccesoTests.class, EjercitoTests.class})
public class SuitTests {
    
}
